﻿namespace LoraAppSerial
{
    partial class Principal
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.guna2AnimateWindow1 = new Guna.UI2.WinForms.Guna2AnimateWindow(this.components);
            this.PainelDefinicoes = new Guna.UI2.WinForms.Guna2Panel();
            this.LBINFO = new System.Windows.Forms.Label();
            this.PINFO = new System.Windows.Forms.PictureBox();
            this.BT = new Guna.UI2.WinForms.Guna2Button();
            this.label2 = new System.Windows.Forms.Label();
            this.CBBR = new Guna.UI2.WinForms.Guna2ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.CBPORTA = new Guna.UI2.WinForms.Guna2ComboBox();
            this.bunifuElipse2 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.Mensagem = new Guna.UI2.WinForms.Guna2MessageDialog();
            this.PainelLeds = new Guna.UI2.WinForms.Guna2Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.PLED4 = new System.Windows.Forms.PictureBox();
            this.PLED3 = new System.Windows.Forms.PictureBox();
            this.PLED2 = new System.Windows.Forms.PictureBox();
            this.PLED1 = new System.Windows.Forms.PictureBox();
            this.BTLED3OF = new Guna.UI2.WinForms.Guna2Button();
            this.BTLED4ON = new Guna.UI2.WinForms.Guna2Button();
            this.BTLED4OF = new Guna.UI2.WinForms.Guna2Button();
            this.BTLED3ON = new Guna.UI2.WinForms.Guna2Button();
            this.BTLED1OF = new Guna.UI2.WinForms.Guna2Button();
            this.BTLED2ON = new Guna.UI2.WinForms.Guna2Button();
            this.BTLED2OF = new Guna.UI2.WinForms.Guna2Button();
            this.BTLED1ON = new Guna.UI2.WinForms.Guna2Button();
            this.bunifuElipse3 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.Tabela = new Guna.UI2.WinForms.Guna2DataGridView();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.PainelDefinicoes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PINFO)).BeginInit();
            this.PainelLeds.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PLED4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PLED3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PLED2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PLED1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tabela)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 30;
            this.bunifuElipse1.TargetControl = this;
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this;
            this.bunifuDragControl1.Vertical = true;
            // 
            // guna2AnimateWindow1
            // 
            this.guna2AnimateWindow1.TargetForm = this;
            // 
            // PainelDefinicoes
            // 
            this.PainelDefinicoes.BackColor = System.Drawing.Color.White;
            this.PainelDefinicoes.BorderRadius = 30;
            this.PainelDefinicoes.Controls.Add(this.LBINFO);
            this.PainelDefinicoes.Controls.Add(this.PINFO);
            this.PainelDefinicoes.Controls.Add(this.BT);
            this.PainelDefinicoes.Controls.Add(this.label2);
            this.PainelDefinicoes.Controls.Add(this.CBBR);
            this.PainelDefinicoes.Controls.Add(this.label1);
            this.PainelDefinicoes.Controls.Add(this.CBPORTA);
            this.PainelDefinicoes.Location = new System.Drawing.Point(12, 12);
            this.PainelDefinicoes.Name = "PainelDefinicoes";
            this.PainelDefinicoes.Size = new System.Drawing.Size(314, 244);
            this.PainelDefinicoes.TabIndex = 0;
            // 
            // LBINFO
            // 
            this.LBINFO.AutoSize = true;
            this.LBINFO.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBINFO.ForeColor = System.Drawing.Color.Red;
            this.LBINFO.Location = new System.Drawing.Point(25, 207);
            this.LBINFO.Name = "LBINFO";
            this.LBINFO.Size = new System.Drawing.Size(180, 19);
            this.LBINFO.TabIndex = 6;
            this.LBINFO.Text = "Dispositivo Conectado";
            // 
            // PINFO
            // 
            this.PINFO.Image = global::LoraAppSerial.Properties.Resources.off;
            this.PINFO.Location = new System.Drawing.Point(256, 188);
            this.PINFO.Name = "PINFO";
            this.PINFO.Size = new System.Drawing.Size(43, 37);
            this.PINFO.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PINFO.TabIndex = 5;
            this.PINFO.TabStop = false;
            // 
            // BT
            // 
            this.BT.Animated = true;
            this.BT.BorderRadius = 15;
            this.BT.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BT.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BT.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BT.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BT.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(67)))), ((int)(((byte)(194)))));
            this.BT.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.BT.ForeColor = System.Drawing.Color.White;
            this.BT.Location = new System.Drawing.Point(71, 155);
            this.BT.Name = "BT";
            this.BT.Size = new System.Drawing.Size(163, 45);
            this.BT.TabIndex = 4;
            this.BT.Text = "Conectar";
            this.BT.Click += new System.EventHandler(this.BT_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Tomato;
            this.label2.Location = new System.Drawing.Point(17, 91);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 19);
            this.label2.TabIndex = 3;
            this.label2.Text = "Baud Rate";
            // 
            // CBBR
            // 
            this.CBBR.BackColor = System.Drawing.Color.Transparent;
            this.CBBR.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(67)))), ((int)(((byte)(194)))));
            this.CBBR.BorderRadius = 10;
            this.CBBR.BorderThickness = 2;
            this.CBBR.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.CBBR.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CBBR.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.CBBR.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.CBBR.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.CBBR.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.CBBR.ItemHeight = 30;
            this.CBBR.Items.AddRange(new object[] {
            "9600"});
            this.CBBR.Location = new System.Drawing.Point(21, 113);
            this.CBBR.Name = "CBBR";
            this.CBBR.Size = new System.Drawing.Size(278, 36);
            this.CBBR.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Tomato;
            this.label1.Location = new System.Drawing.Point(17, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "Porta";
            // 
            // CBPORTA
            // 
            this.CBPORTA.BackColor = System.Drawing.Color.Transparent;
            this.CBPORTA.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(67)))), ((int)(((byte)(194)))));
            this.CBPORTA.BorderRadius = 10;
            this.CBPORTA.BorderThickness = 2;
            this.CBPORTA.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.CBPORTA.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CBPORTA.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.CBPORTA.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.CBPORTA.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.CBPORTA.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.CBPORTA.ItemHeight = 30;
            this.CBPORTA.Location = new System.Drawing.Point(21, 52);
            this.CBPORTA.Name = "CBPORTA";
            this.CBPORTA.Size = new System.Drawing.Size(278, 36);
            this.CBPORTA.TabIndex = 0;
            // 
            // bunifuElipse2
            // 
            this.bunifuElipse2.ElipseRadius = 30;
            this.bunifuElipse2.TargetControl = this.PainelDefinicoes;
            // 
            // serialPort1
            // 
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // Mensagem
            // 
            this.Mensagem.Buttons = Guna.UI2.WinForms.MessageDialogButtons.OK;
            this.Mensagem.Caption = null;
            this.Mensagem.Icon = Guna.UI2.WinForms.MessageDialogIcon.None;
            this.Mensagem.Parent = this;
            this.Mensagem.Style = Guna.UI2.WinForms.MessageDialogStyle.Light;
            this.Mensagem.Text = null;
            // 
            // PainelLeds
            // 
            this.PainelLeds.BackColor = System.Drawing.Color.White;
            this.PainelLeds.Controls.Add(this.guna2Button1);
            this.PainelLeds.Controls.Add(this.pictureBox1);
            this.PainelLeds.Controls.Add(this.PLED4);
            this.PainelLeds.Controls.Add(this.PLED3);
            this.PainelLeds.Controls.Add(this.PLED2);
            this.PainelLeds.Controls.Add(this.PLED1);
            this.PainelLeds.Controls.Add(this.BTLED3OF);
            this.PainelLeds.Controls.Add(this.BTLED4ON);
            this.PainelLeds.Controls.Add(this.BTLED4OF);
            this.PainelLeds.Controls.Add(this.BTLED3ON);
            this.PainelLeds.Controls.Add(this.BTLED1OF);
            this.PainelLeds.Controls.Add(this.BTLED2ON);
            this.PainelLeds.Controls.Add(this.BTLED2OF);
            this.PainelLeds.Controls.Add(this.BTLED1ON);
            this.PainelLeds.Location = new System.Drawing.Point(332, 12);
            this.PainelLeds.Name = "PainelLeds";
            this.PainelLeds.Size = new System.Drawing.Size(545, 234);
            this.PainelLeds.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::LoraAppSerial.Properties.Resources.Foto;
            this.pictureBox1.Location = new System.Drawing.Point(371, 14);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(171, 197);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 18;
            this.pictureBox1.TabStop = false;
            // 
            // PLED4
            // 
            this.PLED4.Image = global::LoraAppSerial.Properties.Resources.off;
            this.PLED4.Location = new System.Drawing.Point(309, 166);
            this.PLED4.Name = "PLED4";
            this.PLED4.Size = new System.Drawing.Size(56, 45);
            this.PLED4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PLED4.TabIndex = 17;
            this.PLED4.TabStop = false;
            // 
            // PLED3
            // 
            this.PLED3.Image = global::LoraAppSerial.Properties.Resources.off;
            this.PLED3.Location = new System.Drawing.Point(309, 118);
            this.PLED3.Name = "PLED3";
            this.PLED3.Size = new System.Drawing.Size(56, 45);
            this.PLED3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PLED3.TabIndex = 16;
            this.PLED3.TabStop = false;
            // 
            // PLED2
            // 
            this.PLED2.Image = global::LoraAppSerial.Properties.Resources.off;
            this.PLED2.Location = new System.Drawing.Point(309, 65);
            this.PLED2.Name = "PLED2";
            this.PLED2.Size = new System.Drawing.Size(56, 45);
            this.PLED2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PLED2.TabIndex = 15;
            this.PLED2.TabStop = false;
            // 
            // PLED1
            // 
            this.PLED1.Image = global::LoraAppSerial.Properties.Resources.off;
            this.PLED1.Location = new System.Drawing.Point(309, 14);
            this.PLED1.Name = "PLED1";
            this.PLED1.Size = new System.Drawing.Size(56, 45);
            this.PLED1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PLED1.TabIndex = 7;
            this.PLED1.TabStop = false;
            // 
            // BTLED3OF
            // 
            this.BTLED3OF.Animated = true;
            this.BTLED3OF.BorderRadius = 15;
            this.BTLED3OF.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BTLED3OF.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BTLED3OF.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BTLED3OF.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BTLED3OF.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(67)))), ((int)(((byte)(194)))));
            this.BTLED3OF.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.BTLED3OF.ForeColor = System.Drawing.Color.White;
            this.BTLED3OF.Location = new System.Drawing.Point(161, 118);
            this.BTLED3OF.Name = "BTLED3OF";
            this.BTLED3OF.Size = new System.Drawing.Size(142, 45);
            this.BTLED3OF.TabIndex = 14;
            this.BTLED3OF.Text = "LED3 OF";
            this.BTLED3OF.Click += new System.EventHandler(this.BTLED3OF_Click);
            // 
            // BTLED4ON
            // 
            this.BTLED4ON.Animated = true;
            this.BTLED4ON.BorderRadius = 15;
            this.BTLED4ON.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BTLED4ON.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BTLED4ON.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BTLED4ON.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BTLED4ON.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(67)))), ((int)(((byte)(194)))));
            this.BTLED4ON.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.BTLED4ON.ForeColor = System.Drawing.Color.White;
            this.BTLED4ON.Location = new System.Drawing.Point(13, 169);
            this.BTLED4ON.Name = "BTLED4ON";
            this.BTLED4ON.Size = new System.Drawing.Size(142, 45);
            this.BTLED4ON.TabIndex = 13;
            this.BTLED4ON.Text = "LED4 ON";
            this.BTLED4ON.Click += new System.EventHandler(this.BTLED4ON_Click);
            // 
            // BTLED4OF
            // 
            this.BTLED4OF.Animated = true;
            this.BTLED4OF.BorderRadius = 15;
            this.BTLED4OF.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BTLED4OF.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BTLED4OF.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BTLED4OF.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BTLED4OF.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(67)))), ((int)(((byte)(194)))));
            this.BTLED4OF.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.BTLED4OF.ForeColor = System.Drawing.Color.White;
            this.BTLED4OF.Location = new System.Drawing.Point(161, 166);
            this.BTLED4OF.Name = "BTLED4OF";
            this.BTLED4OF.Size = new System.Drawing.Size(142, 45);
            this.BTLED4OF.TabIndex = 12;
            this.BTLED4OF.Text = "LED4 OF";
            this.BTLED4OF.Click += new System.EventHandler(this.BTLED4OF_Click);
            // 
            // BTLED3ON
            // 
            this.BTLED3ON.Animated = true;
            this.BTLED3ON.BorderRadius = 15;
            this.BTLED3ON.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BTLED3ON.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BTLED3ON.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BTLED3ON.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BTLED3ON.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(67)))), ((int)(((byte)(194)))));
            this.BTLED3ON.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.BTLED3ON.ForeColor = System.Drawing.Color.White;
            this.BTLED3ON.Location = new System.Drawing.Point(13, 118);
            this.BTLED3ON.Name = "BTLED3ON";
            this.BTLED3ON.Size = new System.Drawing.Size(142, 45);
            this.BTLED3ON.TabIndex = 11;
            this.BTLED3ON.Text = "LED3 ON";
            this.BTLED3ON.Click += new System.EventHandler(this.BTLED3ON_Click);
            // 
            // BTLED1OF
            // 
            this.BTLED1OF.Animated = true;
            this.BTLED1OF.BorderRadius = 15;
            this.BTLED1OF.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BTLED1OF.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BTLED1OF.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BTLED1OF.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BTLED1OF.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(67)))), ((int)(((byte)(194)))));
            this.BTLED1OF.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.BTLED1OF.ForeColor = System.Drawing.Color.White;
            this.BTLED1OF.Location = new System.Drawing.Point(161, 19);
            this.BTLED1OF.Name = "BTLED1OF";
            this.BTLED1OF.Size = new System.Drawing.Size(142, 45);
            this.BTLED1OF.TabIndex = 10;
            this.BTLED1OF.Text = "LED1 OF";
            this.BTLED1OF.Click += new System.EventHandler(this.BTLED1OF_Click);
            // 
            // BTLED2ON
            // 
            this.BTLED2ON.Animated = true;
            this.BTLED2ON.BorderRadius = 15;
            this.BTLED2ON.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BTLED2ON.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BTLED2ON.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BTLED2ON.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BTLED2ON.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(67)))), ((int)(((byte)(194)))));
            this.BTLED2ON.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.BTLED2ON.ForeColor = System.Drawing.Color.White;
            this.BTLED2ON.Location = new System.Drawing.Point(13, 70);
            this.BTLED2ON.Name = "BTLED2ON";
            this.BTLED2ON.Size = new System.Drawing.Size(142, 45);
            this.BTLED2ON.TabIndex = 9;
            this.BTLED2ON.Text = "LED2 ON";
            this.BTLED2ON.Click += new System.EventHandler(this.BTLED2ON_Click);
            // 
            // BTLED2OF
            // 
            this.BTLED2OF.Animated = true;
            this.BTLED2OF.BorderRadius = 15;
            this.BTLED2OF.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BTLED2OF.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BTLED2OF.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BTLED2OF.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BTLED2OF.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(67)))), ((int)(((byte)(194)))));
            this.BTLED2OF.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.BTLED2OF.ForeColor = System.Drawing.Color.White;
            this.BTLED2OF.Location = new System.Drawing.Point(161, 67);
            this.BTLED2OF.Name = "BTLED2OF";
            this.BTLED2OF.Size = new System.Drawing.Size(142, 45);
            this.BTLED2OF.TabIndex = 8;
            this.BTLED2OF.Text = "LED2 OF";
            this.BTLED2OF.Click += new System.EventHandler(this.BTLED2OF_Click);
            // 
            // BTLED1ON
            // 
            this.BTLED1ON.Animated = true;
            this.BTLED1ON.BorderRadius = 15;
            this.BTLED1ON.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BTLED1ON.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BTLED1ON.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BTLED1ON.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BTLED1ON.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(67)))), ((int)(((byte)(194)))));
            this.BTLED1ON.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.BTLED1ON.ForeColor = System.Drawing.Color.White;
            this.BTLED1ON.Location = new System.Drawing.Point(13, 19);
            this.BTLED1ON.Name = "BTLED1ON";
            this.BTLED1ON.Size = new System.Drawing.Size(142, 45);
            this.BTLED1ON.TabIndex = 7;
            this.BTLED1ON.Text = "LED1 ON";
            this.BTLED1ON.Click += new System.EventHandler(this.BTLED1ON_Click);
            // 
            // bunifuElipse3
            // 
            this.bunifuElipse3.ElipseRadius = 30;
            this.bunifuElipse3.TargetControl = this.PainelLeds;
            // 
            // Tabela
            // 
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            this.Tabela.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.Tabela.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Tabela.BackgroundColor = System.Drawing.Color.White;
            this.Tabela.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Tabela.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.Tabela.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Tabela.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.Tabela.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Tabela.DefaultCellStyle = dataGridViewCellStyle6;
            this.Tabela.EnableHeadersVisualStyles = false;
            this.Tabela.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.Tabela.Location = new System.Drawing.Point(12, 262);
            this.Tabela.Name = "Tabela";
            this.Tabela.RowHeadersVisible = false;
            this.Tabela.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Tabela.Size = new System.Drawing.Size(865, 150);
            this.Tabela.TabIndex = 2;
            this.Tabela.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.Tabela.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.Tabela.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.Tabela.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.Tabela.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.Tabela.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.Tabela.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.Tabela.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.Tabela.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.Tabela.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.Tabela.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.Tabela.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Tabela.ThemeStyle.HeaderStyle.Height = 4;
            this.Tabela.ThemeStyle.ReadOnly = false;
            this.Tabela.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.Tabela.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.Tabela.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.Tabela.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.Tabela.ThemeStyle.RowsStyle.Height = 22;
            this.Tabela.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.Tabela.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            // 
            // guna2Button1
            // 
            this.guna2Button1.Animated = true;
            this.guna2Button1.BorderRadius = 15;
            this.guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(67)))), ((int)(((byte)(194)))));
            this.guna2Button1.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.Location = new System.Drawing.Point(478, 19);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.Size = new System.Drawing.Size(53, 45);
            this.guna2Button1.TabIndex = 19;
            this.guna2Button1.Text = "X";
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(889, 450);
            this.Controls.Add(this.Tabela);
            this.Controls.Add(this.PainelLeds);
            this.Controls.Add(this.PainelDefinicoes);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Principal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Principal_Load);
            this.PainelDefinicoes.ResumeLayout(false);
            this.PainelDefinicoes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PINFO)).EndInit();
            this.PainelLeds.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PLED4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PLED3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PLED2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PLED1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tabela)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private Guna.UI2.WinForms.Guna2AnimateWindow guna2AnimateWindow1;
        private Guna.UI2.WinForms.Guna2Panel PainelDefinicoes;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse2;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2ComboBox CBPORTA;
        private Guna.UI2.WinForms.Guna2Button BT;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2ComboBox CBBR;
        private System.Windows.Forms.Label LBINFO;
        private System.Windows.Forms.PictureBox PINFO;
        private System.IO.Ports.SerialPort serialPort1;
        private Guna.UI2.WinForms.Guna2MessageDialog Mensagem;
        private Guna.UI2.WinForms.Guna2Panel PainelLeds;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse3;
        private System.Windows.Forms.PictureBox PLED4;
        private System.Windows.Forms.PictureBox PLED3;
        private System.Windows.Forms.PictureBox PLED2;
        private System.Windows.Forms.PictureBox PLED1;
        private Guna.UI2.WinForms.Guna2Button BTLED3OF;
        private Guna.UI2.WinForms.Guna2Button BTLED4ON;
        private Guna.UI2.WinForms.Guna2Button BTLED4OF;
        private Guna.UI2.WinForms.Guna2Button BTLED3ON;
        private Guna.UI2.WinForms.Guna2Button BTLED1OF;
        private Guna.UI2.WinForms.Guna2Button BTLED2ON;
        private Guna.UI2.WinForms.Guna2Button BTLED2OF;
        private Guna.UI2.WinForms.Guna2Button BTLED1ON;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Guna.UI2.WinForms.Guna2DataGridView Tabela;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
    }
}

