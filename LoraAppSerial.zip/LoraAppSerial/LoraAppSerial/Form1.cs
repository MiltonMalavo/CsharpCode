﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using Guna.UI2.WinForms;
using System.Data.OleDb;

namespace LoraAppSerial
{
    public partial class Principal : Form
    {
        private bool _controla = false;
        private Guna2Button[] bts;
        private string Caminho = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source="+Application.StartupPath+@"\Banco\BD.accdb";

        public Principal()
        {
            InitializeComponent();
            
        }
        
        private void ButtonDefinitions(Guna2Button[] _bt, bool estado)
        {
            foreach (var Todos in _bt){Todos.Enabled = estado;}
          
        }

        public DataTable ObterDados()
        {
            OleDbConnection con = new OleDbConnection(Caminho);
            OleDbDataAdapter adapter = new OleDbDataAdapter("select *from Dados",con);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);
            return dataTable;
        }

        public void Cadastar(string L1,
            string L2, string L3, string L4
            )
        {
            string Comando ="INSERT INTO Dados (LED1,LED2,LED3,LED4,Data, Hora) values(@LED1,@LED2,@LED3,@LED4,@Data, @Hora)";
            OleDbConnection con = new OleDbConnection(Caminho);
            OleDbCommand com = new OleDbCommand(Comando,con);
            com.Parameters.Add("@LED1", OleDbType.VarChar).Value =L1;
            com.Parameters.Add("@LED2", OleDbType.VarChar).Value = L2;
            com.Parameters.Add("@LED3", OleDbType.VarChar).Value = L3;
            com.Parameters.Add("@LED4", OleDbType.VarChar).Value = L4;
            com.Parameters.Add("@Data", OleDbType.VarChar).Value = DateTime.Now.ToLongDateString();
            com.Parameters.Add("@Hora", OleDbType.VarChar).Value = DateTime.Now.ToLongTimeString();
            try
            {
                con.Open();
                com.ExecuteNonQuery();
            }
            catch (Exception a)
            {

                Mensagem.Show("Cadastro",a.Message);
            }
            finally
            {
                con.Close();
            }     
        }
        private void Principal_Load(object sender, EventArgs e)
        {
           
            CBPORTA.DataSource=SerialPort.GetPortNames();
            CBPORTA.SelectedIndex = -1;
            CBBR.SelectedIndex = 0;
            bts = new Guna2Button[8]{ BTLED1OF, BTLED2OF, BTLED3OF,
                BTLED4OF, BTLED1ON,BTLED2ON, BTLED3ON, BTLED4ON
            };
            ButtonDefinitions(bts, false);
          
            Tabela.DataSource = ObterDados();
            
        }
        private void ligar(Guna2Button _guna2ButtonOn,
            Guna2Button _guna2ButtonOF
            , PictureBox pictureBox, string _valor ="")
        {
            _guna2ButtonOF.Enabled = true;
            _guna2ButtonOn.Enabled = false;
            pictureBox.Image = Properties.Resources.on;
            if(_valor!= "")
            {
                serialPort1.WriteLine(_valor);
            }
           
        }

        private void Desligar(Guna2Button _guna2ButtonOn,
          Guna2Button _guna2ButtonOF
          , PictureBox pictureBox, string _valor ="")
        {
            _guna2ButtonOF.Enabled = false;
            _guna2ButtonOn.Enabled = true;
            pictureBox.Image = Properties.Resources.off;
            if (_valor != "")
            {
                serialPort1.WriteLine(_valor);
            }
        }
        private void BT_Click(object sender, EventArgs e)
        {
            if (_controla == false)
            {
                if (string.IsNullOrEmpty(CBPORTA.Text) || string.IsNullOrEmpty(CBBR.Text))
                {
                    Mensagem.Icon = Guna.UI2.WinForms.MessageDialogIcon.Error;
                    Mensagem.Buttons = Guna.UI2.WinForms.MessageDialogButtons.OK;
                    Mensagem.Show("Prencha todos os Campos", "Conectar");
                    return;
                }
                serialPort1.PortName = CBPORTA.Text;
                serialPort1.BaudRate = int.Parse(CBBR.Text);
                serialPort1.Open();

                CBPORTA.Enabled = false;
                CBBR.Enabled = false;
                LBINFO.Text = "Despositivo Conectado";
                LBINFO.ForeColor = Color.Green;

                PINFO.Image = Properties.Resources.on;
                BT.Text = "Desconectar";
                _controla = true;
                ButtonDefinitions(bts, true);
            }
            else
            {
                serialPort1.Close();

                CBPORTA.Enabled = true;
                CBBR.Enabled = true;
                LBINFO.Text = "Despositivo Desconectado";
                LBINFO.ForeColor = Color.Red;

                PINFO.Image = Properties.Resources.off;
                BT.Text = "Conectar";
                _controla = false;
                ButtonDefinitions(bts, false);
            }
        }

        private void BTLED1ON_Click(object sender, EventArgs e)
        {
            
            ligar(BTLED1ON, BTLED1OF, PLED1,"A");
        }

        private void BTLED1OF_Click(object sender, EventArgs e)
        {
            Desligar(BTLED1ON, BTLED1OF, PLED1, "a");
        }

        private void BTLED2ON_Click(object sender, EventArgs e)
        {
            ligar(BTLED2ON, BTLED2OF, PLED2, "B");
        }

        private void BTLED2OF_Click(object sender, EventArgs e)
        {
            Desligar(BTLED2ON, BTLED2OF, PLED2, "b");
        }

        private void BTLED3ON_Click(object sender, EventArgs e)
        {
            ligar(BTLED3ON, BTLED3OF, PLED3, "C");
        }

        private void BTLED3OF_Click(object sender, EventArgs e)
        {
            Desligar(BTLED3ON, BTLED3OF, PLED3, "c");
        }

        private void BTLED4ON_Click(object sender, EventArgs e)
        {
            ligar(BTLED4ON, BTLED4OF, PLED4, "D");
         
        }

        private void BTLED4OF_Click(object sender, EventArgs e)
        {
            Desligar(BTLED4ON, BTLED4OF, PLED4, "d");
        }

        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            this.Invoke(new MethodInvoker(Receber));
        }
        string DadosAnterior ="";
        private void Receber()
        {
            string DadosNovo = serialPort1.ReadLine();
            string[] Dados = serialPort1.ReadLine().Split('*');
            if (Dados[0].Trim().Equals("1")) { ligar(BTLED1ON, BTLED1OF, PLED1); }
            if (Dados[1].Trim().Equals("1")) { ligar(BTLED2ON, BTLED2OF, PLED2); }
            if (Dados[2].Trim().Equals("1")) { ligar(BTLED3ON, BTLED3OF, PLED3); }
            if (Dados[3].Trim().Equals("1")) { ligar(BTLED4ON, BTLED4OF, PLED4); }

            if (Dados[0].Trim().Equals("0")) { Desligar(BTLED1ON, BTLED1OF, PLED1); }
            if (Dados[1].Trim().Equals("0")) { Desligar(BTLED2ON, BTLED2OF, PLED2); }
            if (Dados[2].Trim().Equals("0")) { Desligar(BTLED3ON, BTLED3OF, PLED3); }
            if (Dados[3].Trim().Equals("0")) { Desligar(BTLED4ON, BTLED4OF, PLED4); }

            if (!DadosNovo.Equals(DadosAnterior))
            {
                Cadastar(Dados[0], Dados[1], Dados[2], Dados[3]);
                DadosAnterior = DadosNovo;
                Tabela.DataSource = ObterDados();
            }

        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
